# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, TimestampType, FloatType

import pyspark.sql.functions as F

# COMMAND ----------

catalog_name = 'ecommerce'

brand_schema = StructType([
    StructField('brand_code', StringType(), True),
    StructField('brand_name', StringType(), True),
    StructField('category_code', StringType(), True),
])

# COMMAND ----------

raw_data_path = "/Volumes/ecommerce/source_data/raw/brands/*.csv"

df = spark.read.option('header', "true").option("delimeter", ",").schema(brand_schema).csv(raw_data_path)

df = df.withColumn("_source_file", F.col("_metadata.file_path")) \
    .withColumn("ingested_at", F.current_timestamp())

display(df.limit(5))

# COMMAND ----------

df.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.brz_brands")

# COMMAND ----------

category_schema = StructType([
    StructField('category_code', StringType(), True),
    StructField('category_name', StringType(), True)
])
raw_data_path = "/Volumes/ecommerce/source_data/raw/category/*.csv"

df_raw = spark.read.option('header', "true").option("delimeter", ",").schema(category_schema).csv(raw_data_path)

df_raw = df_raw.withColumn("_ingested_at", F.current_timestamp()) \
                .withColumn("_source_file", F.col("_metadata.file_path"))

df_raw.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.brz_category")

# COMMAND ----------

products_schema = StructType([
    StructField('product_id', StringType(), True),
    StructField('sku', StringType(), True),
    StructField('category_code', StringType(), True),
    StructField('brand_code', StringType(), True),
    StructField('color', StringType(), True),
    StructField('size', StringType(), True),
    StructField('material', StringType(), True),
    StructField('weight_grams', StringType(), True), #string due to incoming data containing anomalies
    StructField('length_cm', StringType(), True), #string due to incoming data containing anomalies
    StructField('width_cm', FloatType(), True),
    StructField('height_cm', FloatType(), True),
    StructField('rating_count', IntegerType(), True),
    StructField('file_name', StringType(), False),
    StructField('ingest_timestamp', TimestampType(), False)   
])

raw_data_path = "/Volumes/ecommerce/source_data/raw/products/*.csv"

df = spark.read.option('header', "true").option("delimeter", ",").schema(products_schema).csv(raw_data_path) \
    .withColumn("file_name", F.col("_metadata.file_path")) \
    .withColumn("ingest_timestamp", F.current_timestamp())

df.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.brz_products")

# COMMAND ----------

customers_schema = StructType([
    StructField('customer_id', StringType(), True),
    StructField('phone', StringType(), True),
    StructField('country_code', StringType(), True),
    StructField('country', StringType(), True),
    StructField('state', StringType(), True),
])

raw_data_path = "/Volumes/ecommerce/source_data/raw/customers/*.csv"

df_raw = spark.read.option('header', "true").option("delimeter", ",").schema(customers_schema).csv(raw_data_path) \
    .withColumn("file_name", F.col("_metadata.file_path")) \
    .withColumn("ingest_timestamp", F.current_timestamp())

df_raw.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.brz_customers")

# COMMAND ----------

date_schema = StructType([
    StructField('date', StringType(), True),
    StructField('year', IntegerType(), True),
    StructField('day_name', StringType(), True),
    StructField('quarter', IntegerType(), True),
    StructField('week_of_year', IntegerType(), True),
])

raw_data_path = "/Volumes/ecommerce/source_data/raw/date/*.csv"

df_raw = spark.read.option('header', "true").option("delimeter", ",").schema(date_schema).csv(raw_data_path) 

df_raw = df_raw.withColumn("_ingested_at", F.current_timestamp()) \
                .withColumn("_source_file", F.col("_metadata.file_path"))

df_raw.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.brz_calendar")

# COMMAND ----------

